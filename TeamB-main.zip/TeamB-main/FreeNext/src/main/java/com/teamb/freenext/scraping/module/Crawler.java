package com.teamb.freenext.scraping.module;

public interface Crawler {

	public void crawl();
	
}
