package com.teamb.freenext;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FreeNextApplicationTests {

	@Test
	void contextLoads() {
	}

}
